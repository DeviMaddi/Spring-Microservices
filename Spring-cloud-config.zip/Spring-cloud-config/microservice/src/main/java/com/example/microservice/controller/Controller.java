package com.example.microservice.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;


@RestController
public class Controller {
    
    @Value("${message}")
    private String message;

    @GetMapping("/message")
    public String getMethodName() {
        return message;
    }
    
}

package com.example.coonfig_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoonfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
